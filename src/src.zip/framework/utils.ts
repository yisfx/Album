

const isMobileF = (): boolean => { return window.screen.height > window.screen.width }
export const isMobile = isMobileF();