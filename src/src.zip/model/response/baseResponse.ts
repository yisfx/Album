export interface BaseResponse {
    Result: boolean
    ErrorMessage: string
}