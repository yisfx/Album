

export class CookieConfig{
    OnlyIdentificationKey:"fx%5OIK"
}


export class CookieUtility{
    
}