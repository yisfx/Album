

export class CookieConfig {
    OnlyIdentificationKey: {
        Key: "fx%5OIK",
        options: {
            path: "/",
            expireAfter: "",
            level: "top",
            secure: true,
            sameSite: "None"
        }
    }
}
