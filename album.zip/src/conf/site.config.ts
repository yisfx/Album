
const SysConfig = {
    port: 9000,

    domain: "http://localhost:9000",

    VisualStaticPath: "/kjsdfh",
    JsPath: "public/script",
    ImagePath: "public/image"
}

export default SysConfig