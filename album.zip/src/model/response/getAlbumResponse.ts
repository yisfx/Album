import { Album } from "../album";

export interface GetAlbumResponse {
    Album: Album
}