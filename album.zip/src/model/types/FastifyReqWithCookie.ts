import { FastifyRequest } from "fastify";
import { FXCellCookie } from "src/framework/cookie/cellFXCookie";


export interface FastifyRequestWithCookie extends FastifyRequest {
    FXCookie: FXCellCookie[] 
}