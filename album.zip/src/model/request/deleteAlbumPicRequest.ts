export interface DeleteAlbumPictureRequest {
    AlbumName: string
    PicName: string
    DeleteType: string
}