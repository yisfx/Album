import { Album } from "../album"


export interface GetAlbumRequest {
    AlbumName:string
}