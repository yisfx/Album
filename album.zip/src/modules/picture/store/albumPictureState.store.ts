import { Album } from "../../../model/album";

export interface AlbumPictureState {
    Album: Album
}