import { Album } from "../../../model/album";

export interface AlbumState {
    AlbumList: Album[]
}