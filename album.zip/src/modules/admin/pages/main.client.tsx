import { render } from "react-dom";
import React from "react";



export class MainPage extends React.Component<any>{
    render() {
        return <div></div>
    }
}

render(
    <MainPage />,
    document.getElementById("app")
)


