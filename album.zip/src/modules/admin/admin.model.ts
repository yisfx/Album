export interface Album {
    AlbumName: string
    ImageCount: number
    Describe: string
    Cover: string
}