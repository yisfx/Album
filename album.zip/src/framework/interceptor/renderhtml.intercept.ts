import { CallHandler, ExecutionContext, NestInterceptor } from "@nestjs/common";
import { ComponentType } from "react";
import { Observable } from "rxjs";


export class RenderHtmlIntercepteor implements NestInterceptor {
  constructor() { }

  intercept(context: ExecutionContext, next: CallHandler<any>): any {
    let reply = context.switchToHttp().getResponse();
    let request = context.switchToHttp().getRequest();
    let element = (context.getHandler() as any)
      .__Root_React_Element__;
    debugger


    return "?????"
  }


}