// import fp from "fastify-plugin";



// export const LoggerPlugin = fp((fastify, opt, done) => {
//     const loggerCfg: LoggerConfig = ConfigService.getConfiguration(
//         "Application.Log"
//     );

//     // remote configs are loaded asynchronously, so loggerCfg might be undefiend at this point
//     if (loggerCfg)
//         createAndUpdateLoggers(loggerCfg.transports);

//     ConfigurationEvents.on<LoggerConfig>("Application.Log", (loggerCfg) => {
//         createAndUpdateLoggers(loggerCfg.transports);
//     });

//     const promClient = (fastify as any).metrics.client;

//     let prmoLogCounter = new promClient.Counter({
//         name: "log_count_trace",
//         help: "Number of log count",
//         labelNames: ["level", "country"],
//     });

//     fastify.decorateRequest("getLogger", function () {
//         let isCAN = isCANRequest(this.hostname, ConfigService as any);

//         let logType = String(isCAN ? LoggerCategory.CAN : LoggerCategory.USA);
//         // if (isDev) {
//         //   logType = "default";
//         // }
//         let logInstance = NegLogger.getInstance().getLogger(logType);
//         let sid = "",
//             tid = "";

//         this.headers["x-gateway-tid"] && (tid = this.headers["x-gateway-tid"]);
//         this.headers["x-gateway-sid"] && (sid = this.headers["x-gateway-sid"]);

//         let requestLogger = logInstance.child({
//             tid,
//             sid,
//         });

//         return new Proxy(requestLogger, {
//             get: (target, propertyName) => {
//                 if (LOG_LEVEL.has(<string>propertyName)) {
//                     prmoLogCounter.inc(<labelValues>{
//                         level: propertyName,
//                         country: logType,
//                     });
//                 }
//                 return (...message) => {
//                     let msg = JSON.stringify(message.join(""));
//                     target[propertyName](msg?.slice(1, msg.length - 1));
//                 };
//             },
//         });
//     });

//     done();
// });
