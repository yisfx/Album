export const ContentType = {
    Script: "application/javascript;charset=utf-8",
    Css: "text/css; charset=utf-8",
    Jpg: "",
    Png: ""
}