

export class DocumentCookie {
    
    constructor() {
        document.cookie.split(";").map(dk => {
            dk.split("=")
        })
    }
}