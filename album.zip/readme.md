
## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ yarn start
```

## Stay in touch
- Website - [www.fxfxfxfx.cn](www.fxfxfxfx.cn)
- docker virual driver host machine windows - [docker virual driver host machine windows](https://www.cnblogs.com/bincoding/p/12009780.html)

## License

  Nest is [MIT licensed](LICENSE).
